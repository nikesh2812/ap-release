=head
# ##################################
# 
# Module : Email.pm
#
# SYNOPSIS
# Send email events on deployment status.
#
# Copyright 2015 eGovernments Foundation
#
#  Log
#  By          	Date        	Change
#  Vasanth KG  	29/11/2015	    Initial Version
#
# #######################################
=cut

# Package name
package Email;

use strict;
use FindBin;



sub notify_release_notes
{
	my ( $par_template_dir, $emailData, $emailWidget, $SUB, $tenant_build_number, $tenant_version, $ENV, $tenant_header,$last_deployed_date) = @_;
	my $YEAR = `date +%Y`;
	my $DATE = `date`;
	chomp $YEAR;
	if ($ENV eq "UAT")
	{
		$tenant_header = $tenant_header." - Since ".$last_deployed_date." (PROD Deploy)";
	}
	my $tmpl = HTML::Template->new( filename => $par_template_dir.'/notify_template.tmpl' );
	$tmpl->param(
   					year     					=> $YEAR,
   					release_table_content 		=> $emailData,
   					release_widget_content		=> $emailWidget,
   					tenant_header				=> $tenant_header
				);
	Email::sendMail($SUB." ".$ENV." #".$tenant_build_number." - Artifact Version ".$tenant_version,$tmpl->output,$ENV);
}

sub sendMail
{
	
    my ($mail_subject, $mail_body, $ENV ) = @_;
    
    #$mail_subject ="ⓓⓔⓥⓞⓟⓢ ". $mail_subject;
    #$mail_subject = $mail_subject;
    
    #$mail_subject = '=?utf-8?Q?'.MIME::Base64::decode("ⓓ").'?='.$mail_subject;
    my $mail_to_list;
    my $SMTP_HOST = "smtp.gmail.com";
    my $SMTP_PORT = "465";
    my $SMTP_USERNAME = "deploy-notifier\@egovernments.org";
    my $SMTP_PASSWORD = Decrypt::getPassword("U2FsdGVkX19LEt0Yk4FlZCy64pGZSmeZEFUTS2fRgH0=");
    if ( $ENV eq "UAT" )
    {
       # $mail_to_list = 'phoenix-qa@egovernments.org,phoenix-team@egovernments.org,teamleads@egovernments.org,dev-managers@egovernments.org,ap-onsite@egovernments.org';
    } 
    else
    {
    	$mail_to_list = 'phoenix-qa@egovernments.org,phoenix-team@egovernments.org,teamleads@egovernments.org,dev-managers@egovernments.org,jawahar.bhandaru@karvy.com,sunil.tiruvaipati@karvy.com,ap-onsite@egovernments.org,nikesh.umredkar@egovernments.org';
    #$mail_to_list = 'nikesh.umredkar@egovernments.org';
    }
    #my $mail_to_list = 'vasanth@egovernments.org';
    my @mail_to = split (',',$mail_to_list);
    my $mail_from = "deploy-notifier\@egovernments.org";
    
    my $smtp;
    my $boundary = "eGOV-DEPLOYMENT";
    
	if (not $smtp = Net::SMTP::SSL->new($SMTP_HOST, Port => $SMTP_PORT )) {
	   print "Could not connect to smtp server.";
	}
		
	$smtp->auth($SMTP_USERNAME, $SMTP_PASSWORD) || die "Authentication failed!\n";
	
	$smtp->mail($mail_from . "\n");
	$smtp->recipient(@mail_to, { SkipBad => 1 });
	
	$smtp->data();
	$smtp->datasend("From: DevOps Support <" . $mail_from . ">\n");
	$smtp->datasend("To:" . $mail_to_list . "\n");
	$smtp->datasend("Cc:devops-support\@egovernments.org\n");
	#$smtp->datasend("Cc:vasanth\@egovernments.org\n");
	$smtp->datasend("Importance: high\n");
	$smtp->datasend("Subject: " . $mail_subject . " \n");
	$smtp->datasend("MIME-Version: 1.0\n");
	$smtp->datasend("Content-type: multipart/mixed;\n\tboundary=\"$boundary\"\n");
	$smtp->datasend("\n");
	$smtp->datasend("\n--$boundary\n");
	$smtp->datasend("Content-type: text/html;charset=\"UTF-8\" \n");
	#$smtp->datasend("Content-Disposition: quoted-printable\n");
	$smtp->datasend("\n");
	$smtp->datasend($mail_body . "\n");
	$smtp->datasend("\n");
	$smtp->dataend();
	$smtp->quit;
}
1;
