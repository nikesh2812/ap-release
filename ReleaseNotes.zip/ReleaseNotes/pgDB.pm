=head
# ##################################
#    Module : pgDB
#
# SYNOPSIS
#  This class is a interface with Postgresql database 
# Copyright 2015 eGovernments Foundation
#
#  Log
#  By      	Date      	Change
#  vasanth 	5/2/16      Initial version
#
# #######################################
=cut


use strict;
use DBI;
our $dbh;

package pgDB;

sub new
{
    my $class = shift;
    my $self = {};
    bless $self, $class;
    return $self;
}


sub connectDB{
	my($self, $server_ip, $username, $password,$databasename) = @_;
	$dbh = DBI->connect("dbi:Pg:dbname=$databasename;host=$server_ip",$username,$password,{AutoCommit=>1,RaiseError=>1,PrintError=>0, pg_enable_utf8=>1});
}

sub disconnectDB{
	$dbh->disconnect();
}

sub quote{
	my($self, $string) = @_;
	return $dbh->quote($string);
}


sub selectQuery{

	my($self, $select_query) = @_;

	my $statement = $dbh->prepare($select_query);
	my $result = $statement->execute();

	my @arr_result ;

	if(!$result){
		print $dbh->errstr;
		return @arr_result;
	}

	while ( my $ref = $statement->fetchrow_hashref() )
	{
			push(@arr_result, $ref);

	}

	return @arr_result;

}


sub selectQueryForRow{
	my($self, $select_query) = @_;

	my $statement = $dbh->prepare($select_query);
	my $result = $statement->execute();

	my @arr_result ;


	if(!$result){
		print $dbh->errstr;
		my $hash_ref = {};
		return $hash_ref;
	}

	return $statement->fetchrow_hashref();

}


sub executeQuery{

	my($self, $query) = @_;
#print $query."\n";
	my $statement = $dbh->prepare($query);
	
	my $result = $statement->execute();

	if (!$result) {
		print $dbh->errstr;
		return 0;
	}
	else{
		return 1;
	}

}

sub executeQueryPrepare{

	my($self, $query,@bindValues) = @_;

	my $statement = $dbh->prepare($query);
	my $result = $statement->execute(@bindValues);

	if (!$result) {
		print $dbh->errstr;
		return 0;
	}
	else{
		return 1;
	}

}
sub executeQuery_Rows{
	my($self, $query) = @_;
	my $statement = $dbh->do($query);
	return $statement;
}
1;
