#!/usr/bin/perl 
=head
# ##################################
# Module : deploy
#
# SYNOPSIS
# This script to Publish the release Notes.
#
# Copyright 2015 eGovernments Foundation
#
#  Log
#  By          	Date        	Change
#  Vasanth KG  	04/02/2016	    Initial Version
#
# #######################################
=cut

# Add template folder to PAR file
# PAR Packager : pp -a template -M DBI -M JSON -M JIRA::REST -M pgDB.pm -M Utils.pm -M Crypt::CBC -M Crypt::Blowfish -M JSON -M Decrypt.pm -M DateTime -M Email.pm -M Common.pm --clean -o ap-release-notify ap-release.pl

# Package name
package release;

use strict;
use FindBin;
use lib "$FindBin::Bin";
use LWP;
#use LWP::UserAgent::ProgressBar;
#use Term::ProgressBar;
use JSON;
use Cwd;
use utf8;
use Encode;
#use MIME::Base64;
use Cwd 'abs_path';
use File::Tee qw(tee);
use File::Basename;
use File::Path qw(make_path remove_tree);
use HTML::Template;
use Common;
use Utils;
use Data::Dumper qw(Dumper);
use MIME::Base64;
use JIRA::REST;
use Net::SMTP::SSL;
#use XML::Simple;
use Crypt::CBC;
use MIME::Base64;
use Email;
use Decrypt;

use constant TRUE => 0;
use constant FALSE => 1;

use constant DATABASE 			=> "devops";
use constant JIRAURL 			=> "http://issues.egovernments.org";
use constant JIRAUSER 			=> "devops";
use constant JIRAPASSWORD 		=> "dev0ps7918";
use constant JIRAPROJECTPREFIX	=> "PHOENIX";

my $tenant_buildnumber = shift or die "ERROR : You must give tenant build number as payload.\n";

my ( $par_template_dir, $tenant_version, $platform_version, $platform_buildnumber, $JSONDATA);

## PAR TEMP path to get the Template path
my $DEBUG = FALSE;
if ( $DEBUG == FALSE )
{
	$par_template_dir = "$ENV{PAR_TEMP}/inc/template";
}
else
{
	$par_template_dir = $FindBin::Bin."/template";
}
#############################################

my $jenkinsUserName = "devops";
my $jenkinsToken = "3379e9ce0762aa047324ffc1ae6517ab";
my $JENKINS_URI = "http://ci.egovernments.org/job";
my $JENKINS_TENANT_JOB="eGov-AP-Impl";
my $JENKINS_PLATFORM_JOB="eGov-Github-QA";

my ( %RELEASE_DATA, $hashJiraData, @arrJiraData, @arrStoreJiraRecords );
my ( $result, $jira_number, @jiraNumbers, $jenkins_job_id, $tenant_arti_version, $platform_artifacts,$platform_arti_version );
my ( %hashdata, $emailData );
my ($issue_type, $jiraNumber, $jira_summary, $issue_status, $issue_status_iconUrl, $issue_type_iconUrl);

my $pgDB = Utils::getDBInstanceGivenDBName(DATABASE);
#my $job_query = "select * from buildartifact_reliance br,jenkins_jobs jjt, project p,
#				account a where a.active = p.active = jjt.active = true and jjt.project_id = p.id 
#				and p.account_id = a.id and br.tenant_job_id=jjt.id
#				and jjt.name = '".$JENKINS_TENANT_JOB."' and br.tenant_build='".$tenant_buildnumber."'";
my $job_query = "select br.tenant_build, br.platform_build, br.tenant_version, br.platform_version, br.tenant_job_id, 
				p.name from buildartifact_reliance br, jenkins_jobs jjt, project p, account a 
				where a.active = p.active = jjt.active = true and jjt.project_id = p.id 
				and p.account_id = a.id and br.tenant_job_id=jjt.id
				and jjt.name = '".$JENKINS_TENANT_JOB."' and br.tenant_build='".$tenant_buildnumber."'";
my $arrBuildDetails = $pgDB->selectQueryForRow($job_query);

if ( $arrBuildDetails ne "" )
{
			$RELEASE_DATA{'result'} = "NA";
			$RELEASE_DATA{'number'} = $arrBuildDetails->{tenant_build};
			$tenant_arti_version 	= $arrBuildDetails->{tenant_version};
			chomp $tenant_arti_version;
#GET THE TENANT JOB ID
			my $tenant_job_id = $arrBuildDetails->{tenant_job_id};
#GET THE PLATFORM VERSION		
			my $platform_buildnumber 	= $arrBuildDetails->{platform_build};
			my $platform_arti_version 	= $arrBuildDetails->{platform_version};
#GET THE PLATFORM JOB ID			
			my $sqlQueryP = "select jjt.id from jenkins_jobs jjt, project p, account a where 
							a.active = p.active = jjt.active = true and jjt.project_id = p.id 
							and p.account_id = a.id and jjt.name ='".$JENKINS_PLATFORM_JOB."'";
			my $platform_job_id = $pgDB->selectQueryForRow($sqlQueryP);

#GET THE JIRA TICKETS since the last release build
			@jiraNumbers = Common::pullJiraTickets( $pgDB, $JENKINS_TENANT_JOB, $RELEASE_DATA{'number'}, $platform_buildnumber, $JENKINS_PLATFORM_JOB );
			my $count;	

			foreach (@jiraNumbers)
			{
				@arrJiraData = jiraUpdateStatus2DB($pgDB,$_->{issue},$RELEASE_DATA{'number'},$tenant_arti_version,$tenant_job_id,$platform_buildnumber,$platform_arti_version,$platform_job_id->{id});
				if ( @arrJiraData )
				{
					push ( @arrStoreJiraRecords, @arrJiraData );
				}
			}
			my ( @issueResults, $i, $tabale_header, $table_footer, @table_data, @td_data);
			my @issues_type_available = getIssuesTypes($pgDB);
			foreach my $issue (@issues_type_available)
			{
				$tabale_header = "<tr style='background:#ccc; background: -webkit-linear-gradient(left, rgba(220,213,213,1) 0%, rgba(222,222,222,0) 100%, rgba(222,222,222,0) 100%, rgba(222,222,222,1) 100%); 
    								background-attachment:fixed;border-bottom: 1px solid #ccc;'><td style='vertical-align: middle;' colspan='3'><h3>".$issue->{name}."</h3></td></tr>";
				foreach (@arrStoreJiraRecords)
				{
					if ( scalar $_ )
					{
						while( my( $key, $value ) = each %{$_})
						{
    						#print "$key: ". Dumper $value;
	    					if ( $key =~ /$issue->{name}/ )
	    					{
	    						push (@td_data , '<tr style="border-bottom: 1px solid #ccc;"><td style="vertical-align: middle;"><img style="display:inline;vertical-align: middle;" src="'.$value->{issue_type_icon}.'" /> <a href="http://issues.egovernments.org/browse/'.JIRAPROJECTPREFIX.'-'.$value->{ticket}.'">'.$value->{ticket}.'</a></td><td style="vertical-align: middle;">'.$value->{issue_summary}.'</td><td><img style="display:inline;vertical-align: middle;" src="'.$value->{status_icon}.'" /> ' .$value->{status}.'</td></tr>');
	    						$count++;
	    					}
	    					
						}
					}					
				}
				if ( scalar @td_data )
				{
					my $temp = join (" ", @td_data);
					@td_data = ();
					push (@table_data, $tabale_header.$temp);
				}
			}
			#Send Release Notes Mail.
			my $DATE = `date`;
			my $mailWidget = '<div style="padding: 5px 10px;margin-left: 90px;"><div><span style="text-transform: uppercase;">AP@ '.$tenant_arti_version.'</span>
<span style="float:right;text-transform: uppercase;">Core@ '.$platform_arti_version.'</span></div>
<div ><span style="font-weight: bold;font-size: 18px;">BN #'.$tenant_buildnumber.'</span>
<span style="float:right;font-weight: bold;font-size: 18px;">BN #'.$platform_buildnumber.'</span></div>
<div style="background: rgba(0,0,0,0.2);margin: 5px -10px 5px -10px;height: 2px;border-radius: 0;">
<div style="width: 100%;float: left;height: 100%;font-size: 12px;line-height: 20px;color: #fff;text-align: center;background-color: #fff;-webkit-box-shadow: inset 0 -1px 0 rgba(0,0,0,.15);box-shadow: inset 0 -1px 0 rgba(0,0,0,.15);-webkit-transition: width .6s ease;-o-transition: width .6s ease;transition: width .6s ease;-webkit-box-shadow: none;box-shadow: none;border-radius: 0;"></div>
</div>
<div><span style="font-size: 14px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;margin: 0;">
'.$count.' Issues Closed
</span>
<span style="float:right;font-size: 14px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;margin: 0;">
'.$DATE.'
</span></div>
</div><!-- /.info-box-content -->';
			$emailData = "<p>What's new in version ".$tenant_arti_version." - #".$RELEASE_DATA{'number'}."
			<table style='border:1px solid #ccc;' cellpadding='5' width='100%'>".join(" ",@table_data)."</table>";
			Email::notify_release_notes($par_template_dir, $emailData, $mailWidget, $arrBuildDetails->{name}, $RELEASE_DATA{'number'}, $tenant_arti_version);
			updateLastReleaseData($pgDB, $RELEASE_DATA{'number'}, $tenant_arti_version, 
			$tenant_job_id,$platform_buildnumber, $platform_arti_version, $platform_job_id, $DATE);
	}
	else 
	{
		print ("Unable to process your request, empty result.\n");
	}
	
	
	
sub getIssuesTypes
{
	my ( $pgDB ) = @_;
	my $query = "select name from issue_type order by id";
	my @issue_type = $pgDB->selectQuery($query);
	return @issue_type;
}	
sub get_snapshot_version
{
	my ( $data ) = @_;
	my $result = `echo $data | rev | cut -d "." -f2- | rev`;
	$result = join('-', (split/-/, $result)[-2, -1]);
	return $result;
}

sub getPlatformDetails
{
	my ($pgDB, $tenant_buildNumber, $tenant_job_id) = @_;
	my $sqlQuery = "select * from buildartifact_reliance where tenant_build = '".$tenant_buildNumber."' and tenant_job_id = '".$tenant_job_id."' order by tenant_build desc limit 1";
	my $arti_results = $pgDB->selectQueryForRow($sqlQuery);
	return ( $arti_results->{platform_build}, $arti_results->{platform_version});
}

sub updateLastReleaseData
{
	my ( $pgDB, $tenant_buildnumber, $tenant_arti_version, $tenant_job_id,$platform_buildnumber, $platform_arti_version, $platform_job_id, $DATE ) = @_;
	my $query = "update last_released set tenant_build_number='".$tenant_buildnumber."',
	tenant_version='".$tenant_arti_version."', 
	tenant_jenkins_jobs_id='".$tenant_job_id."',
	platform_build_number='".$platform_buildnumber."',
	platform_version='".$platform_arti_version."',
	platform_jenkins_jobs_id='".$platform_job_id->{id}."', 
	date='".$DATE."'";
	my $result = $pgDB->executeQuery($query);
	print "SUCCESS" if ( $result );
}

sub jiraUpdateStatus2DB
{
	my ( $pgDB,$jiraNumber,$tenant_buildnumber,$tenant_arti_version,$tenant_job_id,$platform_buildnumber,$platform_arti_version,$platform_job_id ) = @_;
	my ( $query, @hashJiraData);
	my $jira = JIRA::REST->new(JIRAURL, JIRAUSER, JIRAPASSWORD);
	# Get issue
    my $issue = $jira->GET("/issue/".JIRAPROJECTPREFIX."-".$jiraNumber);
    my $jira_summary = $issue->{fields}->{summary};
    my $jira_resolutiondate = $issue->{fields}->{resolutiondate};
	my $issue_type_iconUrl = $issue->{fields}->{issuetype}->{iconUrl};
	my $issue_type = $issue->{fields}->{issuetype}->{name};
	my $issue_status = $issue->{fields}->{status}->{name};
	my $issue_status_iconUrl = $issue->{fields}->{status}->{iconUrl};

	if ( $issue_status eq "Closed" )
	{
		$query = "insert into release_notes ( date,issue,issue_type,issue_status,summary,tenant_build_number,
		platform_build_number, tenant_version, platform_version, tenant_jenkins_jobs_id, paltform_jenkins_jobs_id )
		values ('".$jira_resolutiondate."','".$jiraNumber."','".$issue_type."','".$issue_status."',".$pgDB->quote($jira_summary).",'".
		$tenant_buildnumber."','".$platform_buildnumber."','".$tenant_arti_version."','".$platform_arti_version."','".
		$tenant_job_id."','".$platform_job_id."')";
		my $result = $pgDB->executeQuery($query);
		#print "[ ".JIRAPROJECTPREFIX."-".$jiraNumber." \t] updated successfully to Release Notes.\n" if ( $result );
		
		@hashJiraData = (
			{
					$issue_type =>
					{
						'ticket' => $jiraNumber,
						'status' => $issue_status,
						'status_icon' => $issue_status_iconUrl,
						'issue_summary' => $jira_summary,
						'issue_type'=> $issue_type,
						'issue_type_icon' => $issue_type_iconUrl
					}
			}
		);
		return @hashJiraData;
		#return ( $issue_type, $jiraNumber, $jira_summary, $issue_status, $issue_status_iconUrl, $issue_type_iconUrl);
	}
}
exit 0;
