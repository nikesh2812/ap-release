=head
# ################################################################
#    Module : Utils
#
# SYNOPSIS
#  This module contains common functionalities to be used across
# Copyright 2015 eGovernments Foundation
#
#
#  Log
#  By      	Date      	Change
#  vasanth  5/2/16      Initial version
#
# #################################################################
=cut

package Utils;

# Include standard perl modules here
use strict;

use constant DB_IP => "ci_database";
use constant DB_USERNAME => "postgres";
use constant DB_PASSWORD => "hashesOnPhoenix";

# Auto Flush
$| = 1;

sub getDBInstance{
	my($repoName) = @_;
	use pgDB;

    my $dbName = ""; #= DB_NAME;
	if($repoName ne ""){
		$dbName=$repoName."_CMDB";
		#print "Database Name: $dbName \n";
	}

	my $pgDB = new pgDB();
    $pgDB->connectDB(DB_IP,DB_USERNAME,DB_PASSWORD,$dbName);
	return $pgDB;

}

sub getDBInstanceGivenDBName{
    my($dbName) = @_;
	use pgDB;
	my $pgDB = new pgDB();
    $pgDB->connectDB(DB_IP,DB_USERNAME,DB_PASSWORD,$dbName);
	return $pgDB;
}

#sub getDBInstanceForPassword{
#    my($dbName,$DB_IP) = @_;
#	use pgDB;
#	my $pgDB = new pgDB();
#	if ($DB_IP eq DB2_IP)
#	{
#    	$pgDB->connectDB($DB_IP,DB2_USERNAME,DB2_PASSWORD,$dbName);
#	}
#	if ($DB_IP eq LAB_IP)
#	{
#    	$pgDB->connectDB($DB_IP,LAB_USERNAME,LAB_PASSWORD,$dbName);
#	}
#	return $pgDB;
#}

#_END_

