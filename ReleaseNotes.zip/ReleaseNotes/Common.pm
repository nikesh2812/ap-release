=head
# ##################################
# 
# Module : Common.pm
#
# SYNOPSIS
# Common script (Jenkins Auth, Prepare Release Notes).
#
# Copyright 2015 eGovernments Foundation
#
#  Log
#  By          	Date        	Change
#  Vasanth KG  	29/11/2015	    Initial Version
#
# #######################################
=cut

# Package name
package Common;

use strict;
use FindBin;
use Data::Dumper qw(Dumper);

sub pullJiraTickets
{
	my ( $pgDB, $JENKINS_TENANT_JOB, $tenant_buildnumber, $platform_buildnumber, $JENKINS_PLATFORM_JOB ) = @_;
	#Get all active projects
	chomp $tenant_buildnumber && chomp $platform_buildnumber;
	my $sqlQuery = "select cl.issue from change_logs cl, jenkins_jobs jj, project p, account a, last_released lr where 
					a.active = p.active = jj.active = true and cl.jenkins_jobs_id = jj.id and jj.name in ('eGov-Github-QA', 'eGov-AP-Impl')
					and (cl.build_number between lr.tenant_build_number and ".$tenant_buildnumber.") OR 
					(cl.build_number between lr.platform_build_number and ".$platform_buildnumber.") group by cl.issue order by cl.issue";
	my @jiraTickets = $pgDB->selectQuery($sqlQuery);
	return @jiraTickets;
}

1;